# Aerodyne-CBSE
This is my personal Informatics practices project made on netbeans for the CBSE practical examination. 